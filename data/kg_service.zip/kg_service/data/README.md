# Hotels Data Folder

## 📁 File Placement

Place your `hotels.json` file here:

```
graphCeylon-API/
└── data/
    └── kg_service/
        └── data/
            └── hotels.json    <-- Your file goes here
```

## 📄 Expected Format

The `hotels.json` should contain:

```json
{
  "scrape_metadata": {
    "total_attractions": 50,
    "total_hotels": 165,
    "scrape_date": "2024-01-01"
  },
  "attractions": [
    {
      "attraction": "Sigiriya Rock",
      "hotels": [
        {
          "name": "Hotel Name",
          "gps_coordinates": {
            "latitude": 7.9569,
            "longitude": 80.7594
          },
          "rate_per_night": 50.0,
          "rating": 4.5,
          "amenities": ["wifi", "pool", "parking"],
          "nearby_places": [...]
        }
      ]
    }
  ]
}
```

## 🚀 How to Ingest

After placing the file, run:

```bash
cd ../../services/kg_service/scripts
python ingest_hotels.py
```

Or see the main [SETUP_GUIDE.md](../../services/kg_service/SETUP_GUIDE.md) for detailed instructions.

## ✅ Verification

Check if data was loaded:

**Via Neo4j Browser**:
```cypher
MATCH (h:Hotel) RETURN count(h) as total
```

**Via API**:
```
GET http://localhost:8000/hotels/statistics/overview
```

## 📊 Current Data

- **Location**: `hotels.json`
- **Total Hotels**: 165
- **Cities**: Galle, Matale, Ratnapura, etc.
- **Price Range**: $9 - $922 per night
- **Star Ratings**: 4-5 stars
